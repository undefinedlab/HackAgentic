const dotenv = require("dotenv");
const fs = require("fs");
const readline = require("readline");
const { ChatOpenAI } = require("@langchain/openai");

// Replace the import with a placeholder or alternative
// const { CdpWalletProvider } = require("@coinbase/cdp-sdk");

// Add error handling for missing package
try {
    const { CdpWalletProvider } = require("@coinbase/cdp-sdk");
} catch (error) {
    console.error("Error: @coinbase/cdp-sdk package not found.");
    console.log("\nTo resolve this issue:");
    console.log("1. First, try installing the package:");
    console.log("   npm install @coinbase/cdp-sdk");
    console.log("\nIf you get an authentication error:");
    console.log("2. Ensure you're logged in to npm:");
    console.log("   npm login");
    console.log("\nIf you get a 404 or access denied error:");
    console.log("3. Request access to the package:");
    console.log("   Visit: https://developer.coinbase.com/");
    console.log("4. After getting access, authenticate with Coinbase's registry:");
    console.log("   npm config set @coinbase:registry https://npm.pkg.github.com");
    process.exit(1);
}

dotenv.config();

function validateEnvironment() {
  const missingVars = [];

  const requiredVars = ["OPENAI_API_KEY", "CDP_API_KEY_NAME", "CDP_API_KEY_PRIVATE_KEY"];
  requiredVars.forEach(varName => {
    if (!process.env[varName]) {
      missingVars.push(varName);
    }
  });

  if (missingVars.length > 0) {
    console.error("Error: Required environment variables are not set");
    missingVars.forEach(varName => {
      console.error(`${varName}=your_${varName.toLowerCase()}_here`);
    });
    process.exit(1);
  }

  if (!process.env.NETWORK_ID) {
    console.warn("Warning: NETWORK_ID not set, defaulting to base-sepolia testnet");
  }
}

validateEnvironment();

const WALLET_DATA_FILE = "wallet_data.txt";

async function initializeAgent() {
  try {
    const llm = new ChatOpenAI({
      model: "gpt-4o-mini",
    });

    let walletDataStr = null;

    if (fs.existsSync(WALLET_DATA_FILE)) {
      try {
        walletDataStr = fs.readFileSync(WALLET_DATA_FILE, "utf8");
      } catch (error) {
        console.error("Error reading wallet data:", error);
      }
    }

    const config = {
      apiKeyName: process.env.CDP_API_KEY_NAME,
      apiKeyPrivateKey: process.env.CDP_API_KEY_PRIVATE_KEY?.replace(/\\n/g, "\n"),
      cdpWalletData: walletDataStr || undefined,
      networkId: process.env.NETWORK_ID || "base-sepolia",
    };

    const walletProvider = await CdpWalletProvider.configureWithWallet(config);

    const agentkit = await AgentKit.from({
      walletProvider,
      actionProviders: [
        wethActionProvider(),
        pythActionProvider(),
        walletActionProvider(),
        erc20ActionProvider(),
        cdpApiActionProvider({
          apiKeyName: process.env.CDP_API_KEY_NAME,
          apiKeyPrivateKey: process.env.CDP_API_KEY_PRIVATE_KEY?.replace(/\\n/g, "\n"),
        }),
        cdpWalletActionProvider({
          apiKeyName: process.env.CDP_API_KEY_NAME,
          apiKeyPrivateKey: process.env.CDP_API_KEY_PRIVATE_KEY?.replace(/\\n/g, "\n"),
        }),
      ],
    });

    const tools = await getLangChainTools(agentkit);
    const memory = new MemorySaver();
    const agentConfig = { configurable: { thread_id: "CDP AgentKit Chatbot Example!" } };

    const agent = createReactAgent({
      llm,
      tools,
      checkpointSaver: memory,
      messageModifier: `
        You are an advanced trading strategy agent that helps users create and deploy automated trading systems. Your capabilities include:
        1. Analyzing user input to understand their trading goals and risk tolerance
        2. Generating optimized trading strategies based on technical indicators and market conditions
        3. Writing secure Solidity smart contracts that implement these strategies
        4. Deploying contracts to the blockchain and setting up 24/7 execution
        5. Monitoring and optimizing strategies post-deployment

        When interacting with users:
        - First, gather their trading preferences: asset classes, timeframes, risk level, and capital
        - Suggest appropriate technical indicators and strategy types (e.g., moving average crossover, RSI-based, etc.)
        - Generate and explain the strategy logic in simple terms
        - Write and deploy the corresponding smart contract
        - Set up automated execution and provide the contract address
        - Offer ongoing monitoring and optimization suggestions

        Key rules:
        1. Always verify contract security before deployment
        2. Include proper risk management features (stop-loss, position sizing)
        3. Provide clear explanations of strategy mechanics
        4. Offer to backtest strategies on historical data
        5. Ensure users understand the risks of automated trading
        6. Be available for strategy adjustments and updates

        Example workflow:
        1. User: "I want a BTC/USD strategy that trades on 1-hour charts"
        2. You: "Let's create a moving average crossover strategy. Would you like to use 50/200 EMA? What's your risk tolerance?"
        3. After gathering details, generate and deploy the contract
        4. Provide the contract address and setup instructions
        5. Monitor performance and suggest optimizations

        Remember: Always prioritize security and user education in automated trading.
        `,
    });

    const exportedWallet = await walletProvider.exportWallet();
    fs.writeFileSync(WALLET_DATA_FILE, JSON.stringify(exportedWallet));

    return { agent, config: agentConfig };
  } catch (error) {
    console.error("Failed to initialize agent:", error);
    throw error;
  }
}

async function runAutonomousMode(agent, config, interval = 10) {
  console.log("Starting autonomous mode...");

  while (true) {
    try {
      const thought =
        "Be creative and do something interesting on the blockchain. " +
        "Choose an action or set of actions and execute it that highlights your abilities.";

      const stream = await agent.stream({ messages: [new HumanMessage(thought)] }, config);

      for await (const chunk of stream) {
        if ("agent" in chunk) {
          console.log(chunk.agent.messages[0].content);
        } else if ("tools" in chunk) {
          console.log(chunk.tools.messages[0].content);
        }
        console.log("-------------------");
      }

      await new Promise(resolve => setTimeout(resolve, interval * 1000));
    } catch (error) {
      console.error("Error:", error.message);
      process.exit(1);
    }
  }
}

async function runChatMode(agent, config) {
  console.log("Starting chat mode... Type 'exit' to end.");

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const question = (prompt) =>
    new Promise(resolve => rl.question(prompt, resolve));

  try {
    while (true) {
      const userInput = await question("\nPrompt: ");

      if (userInput.toLowerCase() === "exit") {
        break;
      }

      const stream = await agent.stream({ messages: [new HumanMessage(userInput)] }, config);

      for await (const chunk of stream) {
        if ("agent" in chunk) {
          console.log(chunk.agent.messages[0].content);
        } else if ("tools" in chunk) {
          console.log(chunk.tools.messages[0].content);
        }
        console.log("-------------------");
      }
    }
  } catch (error) {
    console.error("Error:", error.message);
    process.exit(1);
  } finally {
    rl.close();
  }
}

async function chooseMode() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const question = (prompt) =>
    new Promise(resolve => rl.question(prompt, resolve));

  while (true) {
    console.log("\nAvailable modes:");
    console.log("1. chat    - Interactive chat mode");
    console.log("2. auto    - Autonomous action mode");

    const choice = (await question("\nChoose a mode (enter number or name): "))
      .toLowerCase()
      .trim();

    if (choice === "1" || choice === "chat") {
      rl.close();
      return "chat";
    } else if (choice === "2" || choice === "auto") {
      rl.close();
      return "auto";
    }
    console.log("Invalid choice. Please try again.");
  }
}

async function main() {
  try {
    const { agent, config } = await initializeAgent();
    const mode = await chooseMode();

    if (mode === "chat") {
      await runChatMode(agent, config);
    } else {
      await runAutonomousMode(agent, config);
    }
  } catch (error) {
    console.error("Error:", error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  console.log("Starting Agent...");
  main().catch(error => {
    console.error("Fatal error:", error);
    process.exit(1);
  });
} 